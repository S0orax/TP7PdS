#ifndef _MAIN_H_
#define _MAIN_H_

extern int opt_verbeux;

#endif
